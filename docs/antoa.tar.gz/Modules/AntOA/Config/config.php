<?php

return config("antoa");
