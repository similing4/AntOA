Vue.component("AdminHeader", {
	name: 'AdminHeader',
	data(){
	    return {
	    };
	},
	template: ``
});