<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AntOA\\Providers\\AntOAServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AntOA\\Providers\\AntOAServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);